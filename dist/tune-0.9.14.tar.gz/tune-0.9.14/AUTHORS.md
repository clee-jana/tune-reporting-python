## tune-api-python Authors
=======================

We'd like to thank the following people who have contributed to the `tune-api-python` repository.

- Jeff Tanner <jefft@tune.com>
- Lucas Brown <lucas@tune.com>
- Jack Morgan <jack@tune.com>