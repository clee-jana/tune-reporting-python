# tune-api-python Changelog
=======================

Here you can see the full list of changes between each `tune-api-python` release.

Version 0.9.0
--------------

Internal release on October 06, 2014
* Tune Management API Client for Python 3.0

Version 0.9.1
--------------

Internal release on October 12, 2014
* Tune Management API Advertise Reports

Version 0.9.2
--------------

Internal release on October 14, 2014
* Unittests and Examples

Version 0.9.3
--------------

Internal release on October 18, 2014
* Tune Management API Client for Python 2.7 and Python 3.0
Version 0.9.5
--------------

Initial public release on October 22, 2014
* Field validation for parameter fields, sort, filter, group