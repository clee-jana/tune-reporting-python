## tune-api-python Changelog
=======================

Here you can see the full list of changes between each `tune-api-python` release.

Version 0.9.0
--------------

Internal release on October 06, 2014
* Tune Management API Client for Python 3.0

Version 0.9.1
--------------

Internal release on October 12, 2014
* Tune Management API Advertise Reports

Version 0.9.2
--------------

Internal release on October 14, 2014
* Unittests and Examples

Version 0.9.3
--------------

Internal release on October 18, 2014
* Tune Management API Client for Python 2.7 and Python 3.0

Version 0.9.5
--------------

Initial public release on October 22, 2014
* Field validation for parameter fields, sort, filter, group

Version 0.9.6
--------------

Beta public release on October 23, 2014
* Refactored layout of setup, examples, and tests.

Version 0.9.7
--------------

Beta public release on October 27, 2014
* Removed threading from fetch()
* Provided recommended values for exports()

Version 0.9.8
--------------

Beta public release on October 28, 2014
* Unittest fixes for Jenkins

Version 0.9.9
--------------

Beta public release on October 28, 2014
* fetch() and status() on all reporting classes.

Version 0.9.10
--------------

Beta public release on October 30, 2014
* Created endpoint base classes.
* Removed bash scripts and provided Makefile instead.


Version 0.9.11
--------------

Beta public release on October 31, 2014
* Revised fetch to use controller/action.