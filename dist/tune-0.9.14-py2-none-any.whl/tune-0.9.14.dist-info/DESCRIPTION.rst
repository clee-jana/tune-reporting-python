Python Tune Helper Library
----------------------------

DESCRIPTION
The Tune SDK simplifies the process of making calls using the Tune
Management API.
The Tune Management API is for advertisers to export data and
manage their account programmatically.  
See https://github.com/MobileAppTracking/tune-api-python for
more information.

LICENSE The Tune Python Helper Library is distributed under the MIT
License 

